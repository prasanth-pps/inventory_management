<?php $__env->startSection('title', 'Product'); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>
<?php if($message = Session::get('already')): ?>
    <div class="alert alert-danger">
        <p><?php echo e($message); ?> <span class="float-right">X</span></p>
    </div>
<?php endif; ?>

      <div class="card-header row mx-0">
          <h4 class="mb-0 my-auto col-6">
            Add Product               
          </h4>
          <h5 class="mb-0 my-auto text-right col-6">
            <a href="<?php echo e(route('product.index')); ?>" class="btn btn-success">List Of Product</a>                
          </h5>
      </div>
      <div class="card-body">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
          <form class="form-horizontal form-label-left form-val" role="form" action="<?php echo e(route('product.store')); ?>" method="POST">
          <?php echo e(csrf_field()); ?>

              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Select Category <span class="required">*</span></label>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                    <Select  class="form-control col-md-7 col-xs-12 search-list" name="category_id" required>
                    <option value=""> Select Category </option>
                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id')); ?>><?php echo e($category->category_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="error_line"><?php echo e($errors->first('category_name')); ?></span>
                  </div>
              </div>
              <div class=" form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Name <span class="required">*</span></label>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                    <input type="text" id="name" class="form-control col-md-7 col-xs-12" name="product_name" onkeypress="return blockSpecialChar(event)" placeholder="Enter Product Name" value="<?php echo e(old('product_name')); ?>" required>
                    <span class="error_line"><?php echo e($errors->first('product_name')); ?></span>
                  </div>
              </div>
              <div class=" form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Code <span class="required">*</span></label>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                    <input type="text" class="form-control col-md-7 col-xs-12" onkeypress="return blockSpecialChar(event)" name="product_code"  value="<?php echo e(old('product_code')); ?>" placeholder="Enter Product Code">
                    <span class="error_line"><?php echo e($errors->first('product_code')); ?></span>
                  </div>
              </div>
              <div class=" form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">HSN Code </label>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                    <input type="text"  class="form-control col-md-7 col-xs-12" onkeypress="return blockSpecialChar(event)" name="hsn"  value="<?php echo e(old('hsn')); ?>" placeholder="Enter HSN Code">
                    <span class="error_line"><?php echo e($errors->first('hsn')); ?></span>
                  </div>
              </div>
              <div class="form-group">
                <div class="col-md-6 col-md-offset-3">
                  <button type="submit" class="btn btn-primary">Submit</button>
                  <a href="<?php echo e(route('product.index')); ?>" class="btn btn-danger">Cancel</a>
                </div>
              </div>
            </form>
          </div>
<script type="text/javascript">
$(document).ready(function() {
    $('.dropdown-sr').select2();
});


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp7.3\htdocs\inventory_management\resources\views/product/create.blade.php ENDPATH**/ ?>