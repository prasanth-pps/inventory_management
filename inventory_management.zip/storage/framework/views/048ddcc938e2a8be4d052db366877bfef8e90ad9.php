<?php $__env->startSection('title', 'Category'); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>
<?php if($message = Session::get('already')): ?>
    <div class="alert alert-danger">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
    <div class="card-header row mx-0">
          <h4 class="mb-0 my-auto col-6">
            Add Category               
          </h4>
          <h5 class="mb-0 my-auto text-right col-6">
            <a href="<?php echo e(route('category.index')); ?>" class="btn btn-success">List Of Category</a>                
          </h5>
      </div>
    <div class="card-body">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <form class="form-horizontal form-label-left form-val" role="form" action="<?php echo e(route('category.store')); ?>" method="POST">
      <?php echo e(csrf_field()); ?>

          <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 " for="name">Category Name <span class="required">*</span></label>
              <div class="col-md-6 col-sm-6 col-xs-12 <?php echo e($errors->has('category_name') ? 'has-error' : ''); ?>">
                <input type="text" id="name" class="form-control col-md-7 col-xs-12" name="category_name" value="<?php echo e(old('category_name')); ?>" placeholder="Enter Category Name">
                <span class="error_line"><?php echo e($errors->first('category_name')); ?></span>
              </div>
          </div>

          <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="textarea">Description</label>
            <div class="col-md-6 col-sm-6 col-xs-12">
              <textarea id="textarea" name="description" class="form-control col-md-7 col-xs-12"  placeholder="Description"></textarea>
            </div>
          </div>

          <div class="form-group">
            <div class="col-md-6 col-md-offset-3">
              <button type="submit" class="btn btn-primary">Submit</button>
              <a href="<?php echo e(route('category.index')); ?>" class="btn btn-danger">Cancel</a>
            </div>
          </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.3\htdocs\inventory_management\resources\views/category/create.blade.php ENDPATH**/ ?>