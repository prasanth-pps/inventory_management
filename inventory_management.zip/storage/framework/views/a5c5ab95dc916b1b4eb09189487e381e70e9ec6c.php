<?php $__env->startSection('title', 'Product'); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>
 <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success ">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
 <?php if($message = Session::get('deleted')): ?>
        <div class="alert alert-danger ">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
 <?php if($message = Session::get('updated')): ?>
        <div class="alert alert-info ">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <div class="card-header row mx-0">
    <h4 class="mb-0 my-auto col-6">
        List of Product        
    </h4>
    <h5 class="mb-0 my-auto text-right col-6">
        <a class="btn btn-success" href="<?php echo e(route('product.create')); ?>"> Add Product</a>
    </h5>
</div>
    <div class="card-body">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>S.No</th>
            <th>Category Name</th>
            <th>Product Name</th>
            <th>Product Code</th>
            <th>HSN Code</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $i = 1 ?> 
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr role="row" class="odd">
                  <td><?php echo e($i++); ?></td>
                  <td><?php echo e($product->category_det->category_name); ?></td>
                  <td><?php echo e($product->product_name); ?></td>
                  <td><?php echo e($product->product_code); ?></td>
                  <td><?php echo e($product->hsn_code); ?></td>
                  <td>
                  <form action="<?php echo e(route('product.destroy',$product->id)); ?>" method="POST">
                        <a class="btn btn-primary" href="<?php echo e(route('product.edit',$product->id)); ?>">Edit</a>
                        <?php echo e(csrf_field()); ?>

                        <?php echo method_field('DELETE'); ?>
                        <button onclick="return confirm('Are you sure?')" type="submit" class="btn btn-danger">Delete</button>
                  </form>  
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.3\htdocs\inventory_management\resources\views/product/index.blade.php ENDPATH**/ ?>