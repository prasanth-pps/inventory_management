@extends('layouts.app')
@section('title', 'Dashboard')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8" style="height:100px;background: #c1c1c1;font-size: -webkit-xxx-large;">
        <center>Dashboard</center>
        </div>
    </div>
</div>
@endsection
